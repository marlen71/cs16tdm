-- init.lua
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

-- Сначала отдай клиенту конфиг
AddCSLuaFile("modules/config.lua")
AddCSLuaFile("modules/spectator_manager.lua")
AddCSLuaFile("modules/damage_feedback.lua")
AddCSLuaFile("modules/killvoice.lua")

-- init.lua (в самом верху, до include модулей)
util.AddNetworkString("CS16DM_Spec_SetMode")
util.AddNetworkString("CS16DM_Spec_Next")
util.AddNetworkString("CS16DM_Spec_Prev")
util.AddNetworkString("CS16DM_SelectKit")


-- Отправляем клиенту остальные клиентские модули
local clientModules = {
    "modules/hud_client.lua",
    "modules/scoreboard.lua",
    "modules/mapvote.lua",
    "modules/buymenu.lua",
    "modules/team_menu.lua",
    "modules/spectator_manager.lua"
}
for _, f in ipairs(clientModules) do
    AddCSLuaFile(f)
end

include("shared.lua")
AddCSLuaFile("modules/damage_feedback.lua")
AddCSLuaFile("modules/killvoice.lua")
AddCSLuaFile("modules/round_manager.lua")
include("modules/killvoice.lua")

-- Подключаем серверные модули (важно: config.lua первым!)
local serverModules = {
    "modules/config.lua",
    "modules/team_manager.lua",
    "modules/match_manager.lua",
    "modules/mapvote.lua",
    "modules/dropcontrol.lua",
    "modules/antistuck.lua",
    "modules/bots.lua",
    "modules/sv_team_menu.lua",
    "modules/spawn_manager.lua",
    "modules/infinite_ammo.lua",
    "modules/buymenu.lua",
    "modules/spectator_manager.lua",
    "modules/damage_feedback.lua",
    "modules/killvoice.lua",
    "modules/round_manager.lua"
}
for _, f in ipairs(serverModules) do
    include(f)
end
