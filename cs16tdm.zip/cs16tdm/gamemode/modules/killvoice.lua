-- =========================
--  KillVoice (streaks, headshot, knife, локальные звуки)
-- =========================
if SERVER then
    util.AddNetworkString("CS16DM_KillStreak")  -- count или спецкоды
    util.AddNetworkString("CS16DM_Headshot")    -- сигнал headshot-килла
    util.AddNetworkString("CS16DM_KnifeVictim") -- сигнал жертве ножа

    local streaks = {}          -- [ply] = {count, lastKillTime}
    local lastHitGroup = {}     -- [victim] = последний hitgroup перед смертью

    -- Запоминаем последний hitgroup при попадании
    hook.Add("ScalePlayerDamage", "CS16DM_TrackHitgroup", function(ply, hitgroup, dmginfo)
        local attacker = dmginfo:GetAttacker()
        if IsValid(attacker) and attacker:IsPlayer() and attacker ~= ply then
            lastHitGroup[ply] = hitgroup
        end
    end)

    -- Серии убийств + Headshot + ножевые звуки
    hook.Add("PlayerDeath", "CS16DM_KillVoice", function(victim, inflictor, attacker)
        if not IsValid(attacker) or not attacker:IsPlayer() then return end
        if attacker == victim then return end

        -- === Серии убийств ===
        local data = streaks[attacker] or {count = 0, lastKillTime = 0}
        if CurTime() - data.lastKillTime <= 15 then
            data.count = data.count + 1
        else
            data.count = 1
        end
        data.lastKillTime = CurTime()
        streaks[attacker] = data

        net.Start("CS16DM_KillStreak")
        net.WriteInt(data.count, 8)
        net.Send(attacker)

        -- === Headshot (только убийство в голову) ===
        if lastHitGroup[victim] == HITGROUP_HEAD then
            net.Start("CS16DM_Headshot")
            net.Send(attacker)
        end
        lastHitGroup[victim] = nil

        -- === Ножевые убийства (локальные звуки убийце и жертве) ===
        local inflictorClass = IsValid(inflictor) and inflictor:GetClass() or ""
        if inflictorClass == "tfa_cs16_knife" or inflictorClass == "tfa_cs16_knife" then
            -- Убийца: humiliation
            net.Start("CS16DM_KillStreak")
            net.WriteInt(-1, 8) -- спецкод ножевого килла для клиента
            net.Send(attacker)

            -- Жертва: maytheforce
            net.Start("CS16DM_KnifeVictim")
            net.Send(victim)
        end
    end)

    -- Сброс стриков при смерти/долгом простое
    hook.Add("PlayerDisconnected", "CS16DM_ResetStreakOnLeave", function(ply)
        streaks[ply] = nil
        lastHitGroup[ply] = nil
    end)
else -- CLIENT
    -- === Серии убийств HUD + локальные звуки ===
    local streakText = ""
    local streakUntil = 0
    local streakNames = {
        [2] = {"Double Kill!", "cs16dm/killstreak_2.wav"},
        [3] = {"Triple Kill!", "cs16dm/killstreak_3.wav"},
        [4] = {"Quadra Kill!", "cs16dm/killstreak_4.wav"},
        [5] = {"Rampage!", "cs16dm/killstreak_5.wav"},
        [6] = {"Unstoppable!", "cs16dm/killstreak_6.wav"},
    }

    net.Receive("CS16DM_KillStreak", function()
        local code = net.ReadInt(8)

        -- Спецкод: ножевой килл — только звук для убийцы
        if code == -1 then
            surface.PlaySound("cs16dm/humiliation.wav")
            return
        end

        local entry = streakNames[code]
        if entry then
            streakText = entry[1]
            streakUntil = CurTime() + 2.5
            surface.PlaySound(entry[2])
        end
    end)

    hook.Add("HUDPaint", "CS16DM_ShowStreak", function()
        if CurTime() < streakUntil then
            draw.SimpleTextOutlined(
                streakText,
                "Trebuchet24",
                ScrW() / 2, ScrH() / 2 - 100,
                Color(255, 215, 0),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER,
                1, Color(0, 0, 0, 200)
            )
        end
    end)

    -- === Headshot HUD + звук (только при убийстве в голову) ===
    local hsUntil = 0
    net.Receive("CS16DM_Headshot", function()
        hsUntil = CurTime() + 2
        surface.PlaySound("cs16dm/headshot.wav")
    end)

    hook.Add("HUDPaint", "CS16DM_ShowHeadshot", function()
        if CurTime() < hsUntil then
            draw.SimpleTextOutlined(
                "HEADSHOT!",
                "Trebuchet24",
                ScrW() / 2, ScrH() / 2 - 140,
                Color(255, 0, 0),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER,
                1, Color(0, 0, 0, 200)
            )
        end
    end)

    -- === Жертва ножевого убийства: локальный звук ===
    net.Receive("CS16DM_KnifeVictim", function()
        surface.PlaySound("cs16dm/maytheforce.wav")
    end)
end
