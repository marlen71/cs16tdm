-- =========================
--  Match Manager
-- =========================

CS16DM_Match = CS16DM_Match or {
    running = false,
    timeEnd = 0,
    score = {
        [TEAM_T]  = 0,
        [TEAM_CT] = 0,
    }
}

util.AddNetworkString("CS16DM_ShowWinMessage")
util.AddNetworkString("CS16DM_StartMapVote")
util.AddNetworkString("CS16DM_CastVote")

-- Запуск матча
function CS16DM_StartMatch()
    CS16DM_Match.running = true
    CS16DM_Match.timeEnd = CurTime() + GetConVar("cs16tdm_time_limit"):GetInt()
    CS16DM_Match.score[TEAM_T]  = 0
    CS16DM_Match.score[TEAM_CT] = 0

    SetGlobalInt("CS16DM_Score_T", 0)
    SetGlobalInt("CS16DM_Score_CT", 0)
    SetGlobalFloat("CS16DM_TimeEnd", CS16DM_Match.timeEnd)
end

-- Завершение матча
function CS16DM_EndMatch(winnerTeam)
    CS16DM_Match.running = false

    local msg, color
    if winnerTeam == TEAM_T then
        msg, color = "Terrorists WIN", Color(255,100,100)
    elseif winnerTeam == TEAM_CT then
        msg, color = "Counter-Terrorists WIN", Color(80,120,255)
    else
        msg, color = "Round Draw", Color(255,255,255)
    end

    net.Start("CS16DM_ShowWinMessage")
    net.WriteString(msg)
    net.WriteColor(color)
    net.Broadcast()

    -- Через 5 секунд запускаем голосование
    timer.Simple(5, function()
        CS16DM_StartMapVote()
    end)
end

-- Подсчёт убийств
hook.Add("PlayerDeath", "CS16DM_ScoreOnKill", function(victim, inflictor, attacker)
    if not CS16DM_Match.running then return end
    if not (IsValid(attacker) and attacker:IsPlayer() and attacker ~= victim) then return end

    local atkTeam = attacker:Team()
    local vicTeam = victim:Team()

    if (atkTeam == TEAM_T or atkTeam == TEAM_CT) and atkTeam ~= vicTeam then
        CS16DM_Match.score[atkTeam] = (CS16DM_Match.score[atkTeam] or 0) + 1

        if atkTeam == TEAM_T then
            SetGlobalInt("CS16DM_Score_T", CS16DM_Match.score[TEAM_T])
        elseif atkTeam == TEAM_CT then
            SetGlobalInt("CS16DM_Score_CT", CS16DM_Match.score[TEAM_CT])
        end

        local limit = GetConVar("cs16tdm_score_limit"):GetInt()
        if CS16DM_Match.score[atkTeam] >= limit then
            CS16DM_EndMatch(atkTeam)
        end
    end
end)

-- Проверка таймера
hook.Add("Think", "CS16DM_MatchTimeCheck", function()
    if not CS16DM_Match.running then return end
    if CurTime() >= CS16DM_Match.timeEnd then
        local tScore = CS16DM_Match.score[TEAM_T] or 0
        local ctScore = CS16DM_Match.score[TEAM_CT] or 0
        local winner = (tScore == ctScore) and -1 or (tScore > ctScore) and TEAM_T or TEAM_CT
        CS16DM_EndMatch(winner)
    end
end)

-- Автостарт при инициализации
hook.Add("Initialize", "CS16DM_AutoStartMatch", function()
    CS16DM_StartMatch()
end)
