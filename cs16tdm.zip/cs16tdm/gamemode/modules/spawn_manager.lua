
-- =========================
--  Spawn Manager (coords per map)
-- =========================

if SERVER then
    CS16DM_Spawns = {
        ["de_gold_dust2"] = {
        T  = {
        Vector(-813.1, -867.5, 128),
        Vector(-812.5, -704.5, 128),
        Vector(-742, -696.3, 128),
        Vector(-760, -863.6, 128),
        Vector(-703.3, -868.8, 128),
        Vector(-701.4, -716.9, 128),
        Vector(-589.5, -704.7, 128),
        Vector(-602.6, -885.1, 128),
        Vector(-490.3, -690.5, 122.6),
        Vector(-484.7, -879, 121.2),
        Vector(-1047.1, -699, 128),
        Vector(-1057.6, -842.7, 128),
        Vector(-1121.9, -695.1, 128),
        Vector(-1170.3, -856.2, 128)
    },
        CT = { 
        Vector(133.7, 2469, -128),
        Vector(252.3, 2472, -128),
        Vector(357.1, 2470.6, -128),
        Vector(448.1, 2463.7, -128),
        Vector(452.7, 2365.2, -128),
        Vector(355.6, 2374.5, -128),
        Vector(223.5, 2352.9, -128),
        Vector(115.2, 2361.7, -128),
        Vector(364, 2168.7, -128),
        Vector(245.3, 2153.8, -128),
        Vector(162.9, 2164.1, -128),
        Vector(76.2, 2156.2, -128)
    }
    },
    ["gm_extrapool"] = {
        T  = {
        Vector(52.4, 955.4, -416),
        Vector(202.1, 959.5, -416),
        Vector(127, 956, -416),
        Vector(214.2, 846.9, -416),
        Vector(127.6, 842.2, -416),
        Vector(55.8, 856.6, -416),
        Vector(37.3, 788.2, -416),
        Vector(119.3, 782.8, -416),
        Vector(231.6, 775.7, -416)
    },
        CT = { 
        Vector(356, -584.1, -416),
        Vector(264, -570, -416),
        Vector(181.5, -570.3, -416),
        Vector(360.9, -493.1, -416),
        Vector(243.9, -480.1, -416),
        Vector(165.4, -471.9, -416),
        Vector(162.7, -392.4, -416),
        Vector(259.5, -392.3, -416),
        Vector(348.9, -399.9, -416)
    }
    }
    -- ... добавляй нужные карты
    }

    function GM:PlayerSelectSpawn(ply)
        if not IsValid(ply) then return end
        if ply:Team() == TEAM_SPEC then return nil end

        local map = game.GetMap()
        local data = CS16DM_Spawns[map]
        if not data then
            return self.BaseClass:PlayerSelectSpawn(ply)
        end

        local pos
        if ply:Team() == TEAM_T and data.T then
            pos = table.Random(data.T)
        elseif ply:Team() == TEAM_CT and data.CT then
            pos = table.Random(data.CT)
        end

        if pos then
            local spawn = ents.Create("info_player_start")
            spawn:SetPos(pos)
            spawn:Spawn()
            return spawn
        end

        return self.BaseClass:PlayerSelectSpawn(ply)
    end
end
