-- =========================
--  Team Manager
-- =========================

-- Выбор случайной модели для игрока
local function CS16DM_SetPlayerModel(ply)
    if ply:Team() == TEAM_T then
        ply:SetModel(table.Random(CS16DM_MODELS_T))
    elseif ply:Team() == TEAM_CT then
        ply:SetModel(table.Random(CS16DM_MODELS_CT))
    end
end

-- Настройка скоростей
local function CS16DM_SetPlayerSpeeds(ply)
    ply:SetWalkSpeed(CS16DM_Config.walkSpeed)
    ply:SetRunSpeed(CS16DM_Config.runSpeed)
    ply:SetCrouchedWalkSpeed(CS16DM_Config.crouchMult)
end

-- Выдача стандартного оружия при спавне
local function CS16DM_GiveDefaultWeapons(ply)
    if ply:Team() == TEAM_SPEC then return end
    ply:Give("tfa_cs16_knife")

    if ply:Team() == TEAM_T then
        ply:Give("tfa_cs16_glock18")
    elseif ply:Team() == TEAM_CT then
        ply:Give("tfa_cs16_usp")
    end

    if CS16DM_Config.autogiveDefault and CS16DM_Config.kits[1] then
        local kit = CS16DM_Config.kits[1]
        if kit.primary then ply:Give(kit.primary) end
        if kit.pistol then ply:Give(kit.pistol) end
        if kit.grenades then
            for _, g in ipairs(kit.grenades) do
                ply:Give(g)
            end
        end
    end
end

-- Хук при спавне игрока
hook.Add("PlayerSpawn", "CS16DM_PlayerSpawn", function(ply)
    if ply:Team() == TEAM_SPEC then
        -- Полный spectator-режим
        ply:StripWeapons()
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetNoDraw(true)
        ply:SetNotSolid(true)
        ply:DrawShadow(false)
        ply:SetMoveType(MOVETYPE_NOCLIP)
        return
    end

    -- Для T/CT
    ply:UnSpectate()
    CS16DM_SetPlayerModel(ply)
    CS16DM_SetPlayerSpeeds(ply)
    ply:SetNoDraw(false)
    ply:SetNotSolid(false)
    ply:DrawShadow(true)
    ply:SetMoveType(MOVETYPE_WALK)

    CS16DM_SetPlayerModel(ply)
    CS16DM_SetPlayerSpeeds(ply)
    CS16DM_GiveDefaultWeapons(ply)

    -- Автовыдача брони, если её нет
    timer.Simple(0, function()
        if IsValid(ply) and ply:Alive() and ply:Team() ~= TEAM_SPEC then
            if ply:Armor() <= 0 then
                ply:SetArmor(100)
            end
        end
    end)
end)

-- Хук при смене команды
hook.Add("PlayerSetTeam", "CS16DM_PlayerSetTeam", function(ply, oldTeam, newTeam)
    if newTeam == TEAM_SPEC then
        ply:KillSilent()
        ply:StripWeapons()
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetNoDraw(true)
        ply:SetNotSolid(true)
        ply:DrawShadow(false)
        ply:SetMoveType(MOVETYPE_NOCLIP)
    else
        ply:UnSpectate()
        ply:SetNoDraw(false)
        ply:SetNotSolid(false)
        ply:DrawShadow(true)
        ply:SetMoveType(MOVETYPE_WALK)
    end
end)

-- Запрет SPEC подбирать оружие/предметы
hook.Add("PlayerCanPickupWeapon", "CS16DM_SpecNoPickup", function(ply, wep)
    if ply:Team() == TEAM_SPEC then return false end
end)
hook.Add("PlayerCanPickupItem", "CS16DM_SpecNoPickupItem", function(ply, item)
    if ply:Team() == TEAM_SPEC then return false end
end)

-- SPEC не получает урон
hook.Add("PlayerShouldTakeDamage", "CS16DM_SpecNoDamage", function(ply, attacker)
    if ply:Team() == TEAM_SPEC then return false end
end)
