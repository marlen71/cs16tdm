if SERVER then
    util.AddNetworkString("CS16DM_ChangeTeam")

    net.Receive("CS16DM_ChangeTeam", function(len, ply)
        local newTeam = net.ReadInt(8)
        if newTeam ~= TEAM_T and newTeam ~= TEAM_CT and newTeam ~= TEAM_SPEC then return end

        ply:SetTeam(newTeam)

        if newTeam == TEAM_SPEC then
            ply:KillSilent()
            ply:StripWeapons()
            ply:Spectate(OBS_MODE_ROAMING)
        else
            ply:UnSpectate()
            ply:Spawn()
        end
    end)
end
