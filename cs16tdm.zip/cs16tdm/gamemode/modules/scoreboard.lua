-- =========================
--  Scoreboard
-- =========================

if CLIENT then
    -- Шрифты
    surface.CreateFont("CS16SB_Title", {
        font = "Trebuchet24",
        size = 22,
        weight = 800
    })

    surface.CreateFont("CS16SB_Text", {
        font = "Trebuchet18",
        size = 18,
        weight = 500
    })

    -- =========================
    --  Строка игрока
    -- =========================
    local PLAYER_LINE = {
        Init = function(self)
            self:SetTall(28)
            self:Dock(TOP)
            self:DockMargin(2,2,2,0)

            self.Avatar = self:Add("AvatarImage")
            self.Avatar:Dock(LEFT)
            self.Avatar:SetWide(28)
            self.Avatar:DockMargin(0,0,5,0)

            self.Name = self:Add("DLabel")
            self.Name:Dock(LEFT)
            self.Name:SetWide(300)
            self.Name:SetFont("CS16SB_Text")
            self.Name:SetTextColor(Color(255,255,255))
            self.Name:SetContentAlignment(4)

            self.Kills = self:Add("DLabel")
            self.Kills:Dock(LEFT)
            self.Kills:SetWide(60)
            self.Kills:SetFont("CS16SB_Text")
            self.Kills:SetTextColor(Color(255,255,255))
            self.Kills:SetContentAlignment(5)

            self.Deaths = self:Add("DLabel")
            self.Deaths:Dock(LEFT)
            self.Deaths:SetWide(60)
            self.Deaths:SetFont("CS16SB_Text")
            self.Deaths:SetTextColor(Color(255,255,255))
            self.Deaths:SetContentAlignment(5)

            self.Ping = self:Add("DLabel")
            self.Ping:Dock(LEFT)
            self.Ping:SetWide(60)
            self.Ping:SetFont("CS16SB_Text")
            self.Ping:SetTextColor(Color(255,255,255))
            self.Ping:SetContentAlignment(5)
        end,

        Setup = function(self, ply)
            self.Player = ply
            self.Avatar:SetPlayer(ply, 32)
            self:Think()
        end,

        Think = function(self)
            if not IsValid(self.Player) then self:Remove() return end
            self.Name:SetText(self.Player:Nick())
            self.Kills:SetText(self.Player:GetNWInt("CS16DM_Kills", self.Player:Frags()))
            self.Deaths:SetText(self.Player:Deaths())
            self.Ping:SetText(self.Player:Ping())
        end,

        Paint = function(self,w,h)
            if self.Player == LocalPlayer() then
                surface.SetDrawColor(255,255,0,40)
                surface.DrawRect(0,0,w,h)
            else
                surface.SetDrawColor(0,0,0,100)
                surface.DrawRect(0,0,w,h)
            end
        end
    }
    PLAYER_LINE = vgui.RegisterTable(PLAYER_LINE, "DPanel")

    -- =========================
    --  Секция команды
    -- =========================
    local TEAM_SECTION = {
        Init = function(self)
            self:Dock(TOP)
            self:DockMargin(10,10,10,0)
            self:SetTall(200)

            self.Header = self:Add("DLabel")
            self.Header:Dock(TOP)
            self.Header:SetTall(24)
            self.Header:SetFont("CS16SB_Text")
            self.Header:SetTextColor(Color(255,215,0))
            self.Header:SetContentAlignment(5)

            self.Columns = self:Add("DPanel")
            self.Columns:Dock(TOP)
            self.Columns:SetTall(20)
            self.Columns.Paint = function(p,w,h)
                draw.SimpleText("Nick",   "CS16SB_Text", 40, h/2, Color(200,200,200), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                draw.SimpleText("Kills",  "CS16SB_Text", 400, h/2, Color(200,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText("Deaths", "CS16SB_Text", 480, h/2, Color(200,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText("Ping",   "CS16SB_Text", 560, h/2, Color(200,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end

            self.Scroll = self:Add("DScrollPanel")
            self.Scroll:Dock(FILL)

            self.List = self.Scroll:Add("DListLayout")
            self.List:Dock(FILL)

            self.LastSnapshot = {}
        end,

        Setup = function(self, teamId, name, color)
            self.TeamId = teamId
            self.TeamName = name
            self.Color = color
        end,

        Rebuild = function(self)
    if not self.TeamId then return end
    local players = team.GetPlayers(self.TeamId)

    -- Сортировка
    table.sort(players, function(a,b)
        if not IsValid(a) or not IsValid(b) then return false end
        local ka, kb = a:GetNWInt("CS16DM_Kills",a:Frags()), b:GetNWInt("CS16DM_Kills",b:Frags())
        if ka == kb then
            return a:Deaths() < b:Deaths()
        end
        return ka > kb
    end)

    self.Header:SetText(self.TeamName.." ("..#players..")")

    -- Полностью пересобираем список
    self.List:Clear()
    for _, pl in ipairs(players) do
        if IsValid(pl) then
            local line = vgui.CreateFromTable(PLAYER_LINE)
            line:Setup(pl)
            self.List:Add(line)
        end
    end
end,

        Paint = function(self,w,h)
            surface.SetDrawColor(10,10,10,180)
            surface.DrawRect(0,0,w,h)
            surface.SetDrawColor(255,215,0,255)
            surface.DrawOutlinedRect(0,0,w,h)
        end
    }
    TEAM_SECTION = vgui.RegisterTable(TEAM_SECTION, "DPanel")

    -- =========================
    --  Главный скорборд
    -- =========================
    local SCORE_BOARD
    SCORE_BOARD = {
        Init = function(self)
            self:SetSize(900, 680)
            self:Center()

            self.Title = self:Add("DLabel")
            self.Title:Dock(TOP)
            self.Title:SetTall(40)
            self.Title:SetFont("CS16SB_Title")
            self.Title:SetTextColor(Color(255,215,0))
            self.Title:SetContentAlignment(5)

            self.TSection = vgui.CreateFromTable(TEAM_SECTION, self)
            self.TSection:Setup(TEAM_T, "Terrorists", Color(200,100,50))

            self.CTSection = vgui.CreateFromTable(TEAM_SECTION, self)
            self.CTSection:Setup(TEAM_CT, "Counter-Terrorists", Color(50,100,200))

            self.SpecSection = vgui.CreateFromTable(TEAM_SECTION, self)
            self.SpecSection:Setup(TEAM_SPEC, "Spectators", Color(150,150,150))
        end,

        Think = function(self)
    self.Title:SetText(GetHostName())

    if not self.NextUpdate or CurTime() >= self.NextUpdate then
        self.NextUpdate = CurTime() + 1 -- обновление раз в секунду
        if IsValid(self.TSection) then self.TSection:Rebuild() end
        if IsValid(self.CTSection) then self.CTSection:Rebuild() end
        if IsValid(self.SpecSection) then self.SpecSection:Rebuild() end
    end
end,

        Paint = function(self,w,h)
            surface.SetDrawColor(10,10,10,200)
            surface.DrawRect(0,0,w,h)
            surface.SetDrawColor(255,215,0,255)
            surface.DrawOutlinedRect(0,0,w,h)
        end
    }
    SCORE_BOARD = vgui.RegisterTable(SCORE_BOARD, "EditablePanel")

    -- =========================
    --  Хуки показа/скрытия
    -- =========================
    local Scoreboard

    hook.Add("ScoreboardShow","CS16_ShowSB",function()
        if not IsValid(Scoreboard) then
            Scoreboard = vgui.CreateFromTable(SCORE_BOARD)
        end
        Scoreboard:Show()
        Scoreboard:MakePopup()
        Scoreboard:SetKeyboardInputEnabled(false)
        return false
    end)

    hook.Add("ScoreboardHide","CS16_HideSB",function()
        if IsValid(Scoreboard) then
            Scoreboard:Hide()
        end
        return false
    end)
end
