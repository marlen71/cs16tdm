-- =========================
--  CS16DM Team Menu
-- =========================

if CLIENT then
    local TeamMenuOpen = false

    local function ToggleTeamMenu()
        TeamMenuOpen = not TeamMenuOpen
    end

    -- Открытие меню по кнопке M
    hook.Add("PlayerButtonDown", "CS16DM_TeamMenuKey", function(ply, key)
        if ply ~= LocalPlayer() then return end
        if key == KEY_M then
            ToggleTeamMenu()
            return
        end

        if not TeamMenuOpen then return end

        if key >= KEY_1 and key <= KEY_9 then
            local choice = key - KEY_0
            if choice == 1 then
                net.Start("CS16DM_ChangeTeam")
                net.WriteInt(TEAM_T, 8)
                net.SendToServer()
                TeamMenuOpen = false
            elseif choice == 2 then
                net.Start("CS16DM_ChangeTeam")
                net.WriteInt(TEAM_CT, 8)
                net.SendToServer()
                TeamMenuOpen = false
            elseif choice == 3 then
                net.Start("CS16DM_ChangeTeam")
                net.WriteInt(TEAM_SPEC, 8)
                net.SendToServer()
                TeamMenuOpen = false
            elseif choice == 9 or choice == 0 then
                TeamMenuOpen = false
            end
        elseif key == KEY_0 then
            TeamMenuOpen = false
        end
    end)

    -- HUD‑отрисовка меню
    hook.Add("HUDPaint", "CS16DM_TeamMenuHUD", function()
        if not TeamMenuOpen then return end

        local x, y = 50, ScrH() / 2 - 100
        draw.SimpleText("=== Choose Team ===", "Trebuchet24", x, y, Color(255,255,0))
        y = y + 30
        draw.SimpleText("1. Terrorists", "Trebuchet18", x, y, Color(220,180,60)); y = y + 20
        draw.SimpleText("2. Counter-Terrorists", "Trebuchet18", x, y, Color(60,120,220)); y = y + 20
        draw.SimpleText("3. Spectators", "Trebuchet18", x, y, Color(200,200,200)); y = y + 20
        draw.SimpleText("9. Return", "Trebuchet18", x, y, Color(200,200,200)); y = y + 20
        draw.SimpleText("0. Exit", "Trebuchet18", x, y, Color(200,200,200))
    end)
end

-- =========================
--  Серверная часть
-- =========================
if SERVER then
    util.AddNetworkString("CS16DM_ChangeTeam")

    net.Receive("CS16DM_ChangeTeam", function(_, ply)
        local newTeam = net.ReadInt(8)
        if newTeam ~= TEAM_T and newTeam ~= TEAM_CT and newTeam ~= TEAM_SPEC then return end

        ply:SetTeam(newTeam)

        if newTeam == TEAM_SPEC then
            ply:KillSilent()
            ply:StripWeapons()
            ply:Spectate(OBS_MODE_ROAMING)
        else
            ply:UnSpectate()
            ply:Spawn()
        end
    end)

    -- Установка модели игрока при спавне
    hook.Add("PlayerSpawn", "CS16DM_SetPlayerModel", function(ply)
        if ply:Team() == TEAM_T then
            local mdl = table.Random(CS16DM_MODELS_T)
            ply:SetModel(mdl)
        elseif ply:Team() == TEAM_CT then
            local mdl = table.Random(CS16DM_MODELS_CT)
            ply:SetModel(mdl)
        elseif ply:Team() == TEAM_SPEC then
            ply:KillSilent()
            ply:StripWeapons()
            ply:Spectate(OBS_MODE_ROAMING)
        end
    end)
end
