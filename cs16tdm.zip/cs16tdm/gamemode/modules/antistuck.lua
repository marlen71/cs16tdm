-- =========================
--  Anti-Stuck System
-- =========================

if SERVER then
    -- Функция раздвижки игроков
    local function CS16DM_AntiStuck(ply)
        if not IsValid(ply) or not ply:Alive() then return end

        local pos = ply:GetPos()
        local nearby = ents.FindInSphere(pos, 40) -- радиус проверки

        local players = {}
        for _, ent in ipairs(nearby) do
            if ent:IsPlayer() and ent:Alive() and ent ~= ply then
                table.insert(players, ent)
            end
        end

        if #players > 0 then
            -- Раздвигаем всех участников
            local angleStep = 360 / (#players + 1)
            local radius = 50

            local all = {ply}
            table.Add(all, players)

            for i, pl in ipairs(all) do
                local ang = math.rad(i * angleStep)
                local offset = Vector(math.cos(ang), math.sin(ang), 0) * radius
                local newPos = pos + offset

                -- Трассировка, чтобы не закинуть в стену
                local tr = util.TraceHull({
                    start = newPos,
                    endpos = newPos,
                    mins = Vector(-16,-16,0),
                    maxs = Vector(16,16,72),
                    mask = MASK_PLAYERSOLID
                })

                if not tr.Hit then
                    pl:SetPos(newPos)
                end
            end
        end
    end

    -- Хук на спавн
    hook.Add("PlayerSpawn", "CS16DM_AntiStuckOnSpawn", function(ply)
        timer.Simple(0.1, function()
            if IsValid(ply) then
                CS16DM_AntiStuck(ply)
            end
        end)
    end)
end
