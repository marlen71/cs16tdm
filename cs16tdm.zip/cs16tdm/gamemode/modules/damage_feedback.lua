-- =========================
--  Damage Feedback (HUD)
-- =========================
if SERVER then
    util.AddNetworkString("CS16DM_DamageInfo")

    hook.Add("EntityTakeDamage", "CS16DM_DamageSend", function(target, dmginfo)
        local attacker = dmginfo:GetAttacker()
        if not IsValid(attacker) or not attacker:IsPlayer() then return end
        if not target:IsPlayer() then return end
        if attacker == target then return end

        local dmg = math.floor(dmginfo:GetDamage())
        if dmg > 0 then
            net.Start("CS16DM_DamageInfo")
            net.WriteInt(dmg, 16)
            net.Send(attacker)
        end
    end)
end

if CLIENT then
    local lastDamage = 0
    local showUntil = 0

    net.Receive("CS16DM_DamageInfo", function()
        lastDamage = net.ReadInt(16)
        showUntil = CurTime() + 1.0
    end)

    hook.Add("HUDPaint", "CS16DM_ShowDamage", function()
        if CurTime() < showUntil then
            draw.SimpleTextOutlined(
                tostring(lastDamage),
                "Trebuchet24",
                ScrW()/2, ScrH()/2 + 40,
                Color(255, 50, 50),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER,
                1, Color(0,0,0,200)
            )
        end
    end)
end
