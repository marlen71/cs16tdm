-- =========================
--  CS16DM Infinite Reserve Ammo
-- =========================

if SERVER then
    -- Список типов патронов, которые используются TFA CS 1.6
    local ammoTypes = {
        "Pistol",       -- Glock, USP, Deagle, P228, FiveSeven, Elites
        "SMG1",         -- MP5, TMP, MAC10, UMP, P90
        "AR2",          -- M4A1, AK47, FAMAS, Galil, AUG, SG552
        "Buckshot",     -- M3, XM1014
        "SniperRound",  -- Scout, AWP
        "357",          -- G3SG1, SG550
        "SMG1_Grenade", -- подствольники (если есть)
        "RPG_Round",    -- M249 (иногда использует Rifle ammo, но на всякий случай)
        "Bolts",
    }

    -- Функция выдачи "бесконечных" патронов
    local function GiveInfiniteAmmo(ply)
        if not IsValid(ply) then return end
        for _, ammo in ipairs(ammoTypes) do
            ply:SetAmmo(9999, ammo) -- фактически бесконечный запас
        end
    end

    -- При спавне игрока
    hook.Add("PlayerSpawn", "CS16DM_InfiniteAmmoOnSpawn", function(ply)
        timer.Simple(0.2, function()
            if IsValid(ply) then
                GiveInfiniteAmmo(ply)
            end
        end)
    end)

    -- При выдаче оружия (например, через меню)
    hook.Add("PlayerLoadout", "CS16DM_InfiniteAmmoOnLoadout", function(ply)
        timer.Simple(0.2, function()
            if IsValid(ply) then
                GiveInfiniteAmmo(ply)
            end
        end)
    end)

    -- При подборе оружия
    hook.Add("WeaponEquip", "CS16DM_InfiniteAmmoOnEquip", function(wep, ply)
        timer.Simple(0.2, function()
            if IsValid(ply) then
                GiveInfiniteAmmo(ply)
            end
        end)
    end)
end
