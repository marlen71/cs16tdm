-- =========================
--  Drop Weapon Control
-- =========================

if SERVER then
    -- Хук на попытку выбросить оружие
    hook.Add("canDropWeapon", "CS16DM_BlockDrop", function(ply, wep)
        if not IsValid(wep) then return false end
        local class = wep:GetClass()

        -- Проверяем список запрещённых
        if CS16DM_Config.noDrop[class] then
            ply:ChatPrint("Нельзя выбросить это оружие!")
            return false
        end

        return true -- остальное можно выбрасывать
    end)

    -- Хук на выброс оружия (для очистки слотов)
    hook.Add("PlayerDroppedWeapon", "CS16DM_ClearSlotOnDrop", function(ply, wep)
        if not IsValid(wep) then return end
        local slot = CS16DM_Config.GetWeaponSlot(wep:GetClass())
        if slot then
            -- Можно добавить логику очистки/логирования
            -- Например: ply.LastDroppedSlot = slot
        end
    end)
end
