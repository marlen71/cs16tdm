-- =========================
--  CS16DM Config
-- =========================
CS16DM_Config = CS16DM_Config or {}

-- Скорости движения (как в CS 1.6)
CS16DM_Config.walkSpeed   = 250
CS16DM_Config.runSpeed    = 80
CS16DM_Config.crouchMult  = 0.20

-- Ограничение гранат: HE(1), Flash(2), Smoke(1)
CS16DM_Config.grenadeLimits = {
    ["weapon_cs16_hegrenade"]    = 1,
    ["weapon_cs16_flashbang"]    = 2,
    ["weapon_cs16_smokegrenade"] = 1,
}

-- Запрещённые к выбросу (Drop Weapon аддон)
CS16DM_Config.noDrop = {
    ["weapon_cs16_flashbang"]     = true,
    ["weapon_cs16_hegrenade"]     = true,
    ["weapon_cs16_smokegrenade"]  = true,
    ["tfa_cs16_knife"]         = true
}

-- Слоты оружия
-- 1 — нож, 2 — пистолет, 3 — основное, 4 — гранаты
function CS16DM_Config.GetWeaponSlot(class)
    local c = string.lower(class)
    if c:find("knife", 1, true) then return 1 end
    if c:find("hegrenade", 1, true) or c:find("flashbang", 1, true) or c:find("smokegrenade", 1, true) then return 4 end
    if c:find("glock", 1, true) or c:find("usp", 1, true) or c:find("deagle", 1, true)
    or c:find("elite", 1, true) or c:find("p228", 1, true) or c:find("fiveseven", 1, true) then return 2 end
    return 3
end

-- Киты (комплекты оружия)
CS16DM_Config.kits = {
    {
        id = "ak_deagle_nades",
        name = "AK-47 + Deagle + Grenades",
        pistol = "tfa_cs16_deagle",
        primary = "tfa_cs16_ak47",
        grenades = {
            "weapon_cs16_hegrenade",
            "weapon_cs16_flashbang",
            "weapon_cs16_flashbang",
            "weapon_cs16_smokegrenade",
        },
    },
    {
        id = "m4_usp_nades",
        name = "M4A1 + USP + Grenades",
        pistol = "tfa_cs16_usp",
        primary = "tfa_cs16_m4a1",
        grenades = {
            "weapon_cs16_hegrenade",
            "weapon_cs16_flashbang",
            "weapon_cs16_flashbang",
            "weapon_cs16_smokegrenade",
        },
    },
    {
        id = "awp_deagle_nades",
        name = "AWP + Deagle + Grenades",
        pistol = "tfa_cs16_deagle",
        primary = "tfa_cs16_awp",
        grenades = {
            "weapon_cs16_hegrenade",
            "weapon_cs16_flashbang",
            "weapon_cs16_flashbang",
            "weapon_cs16_smokegrenade",
        },
    },
}

-- Автовыдача набора при респавне
CS16DM_Config.autogiveDefault = false
