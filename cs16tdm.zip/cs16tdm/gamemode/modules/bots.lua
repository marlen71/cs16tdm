-- =========================
--  Bots (CS 1.6 style)
-- =========================

if SERVER then
    -- Добавить бота в CT
    concommand.Add("bot_add_ct", function(ply)
        if IsValid(ply) and not ply:IsAdmin() then return end

        local name = "CT_Bot_"..math.random(1000,9999)
        local bot = player.CreateNextBot(name)
        if IsValid(bot) then
            bot:SetTeam(TEAM_CT)
            bot:Spawn()
            print("[CS16DM] Бот добавлен в CT: "..name)
        end
    end)

    -- Добавить бота в T
    concommand.Add("bot_add_t", function(ply)
        if IsValid(ply) and not ply:IsAdmin() then return end

        local name = "T_Bot_"..math.random(1000,9999)
        local bot = player.CreateNextBot(name)
        if IsValid(bot) then
            bot:SetTeam(TEAM_T)
            bot:Spawn()
            print("[CS16DM] Бот добавлен в T: "..name)
        end
    end)

    -- Добавить HLTV-ботов (наблюдатели)
    concommand.Add("bot_add_hltv", function(ply)
        if IsValid(ply) and not ply:IsAdmin() then return end

        local names = {
            "created by marlen",
            "https://discord.gg/WmWrjhF3ad",
            "dev 0.1"
        }

        for _, name in ipairs(names) do
            local bot = player.CreateNextBot(name)
            if IsValid(bot) then
                bot:SetTeam(TEAM_SPEC)
                bot:KillSilent()
                bot:StripWeapons()
                bot:Spectate(OBS_MODE_ROAMING)
                print("[CS16DM] HLTV-бот добавлен: "..name)
            end
        end
    end)

    -- Простая логика для боевых ботов (CT/T)
    hook.Add("Think", "CS16DM_BotAI", function()
        for _, bot in ipairs(player.GetBots()) do
            if not IsValid(bot) or not bot:Alive() then continue end
            if bot:Team() == TEAM_SPEC then continue end -- HLTV не играют

            -- Ищем ближайшего врага
            if not IsValid(bot.Target) or not bot.Target:Alive() or bot.Target:Team() == bot:Team() then
                local nearest, dist = nil, math.huge
                for _, ply in ipairs(player.GetAll()) do
                    if ply ~= bot and ply:Alive() and ply:Team() ~= bot:Team() then
                        local d = bot:GetPos():DistToSqr(ply:GetPos())
                        if d < dist then
                            dist = d
                            nearest = ply
                        end
                    end
                end
                bot.Target = nearest
            end

            -- Если есть цель — идём к ней и стреляем
            if IsValid(bot.Target) then
                local dir = (bot.Target:GetPos() - bot:GetPos()):GetNormalized()
                bot:SetEyeAngles((bot.Target:GetPos() - bot:GetShootPos()):Angle())
                bot:SetVelocity(dir * 200)

                local wep = bot:GetActiveWeapon()
                if IsValid(wep) then
                    bot:ConCommand("+attack")
                    timer.Simple(0.1, function()
                        if IsValid(bot) then bot:ConCommand("-attack") end
                    end)
                end
            end
        end
    end)
end
