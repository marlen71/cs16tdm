-- =========================
--  CS16DM Kit Menu (BuyMenu → текстовый HUD)
-- =========================

-- Клиентская часть: текстовое меню на HUD, выбор цифрами
if CLIENT then
    local KitMenuOpen = false

    local function ToggleKitMenu()
        -- простое переключение
        KitMenuOpen = not KitMenuOpen
    end

    -- Открытие/управление меню по клавишам
    hook.Add("PlayerButtonDown", "CS16DM_KitMenuKey", function(ply, key)
        if ply ~= LocalPlayer() then return end

        -- Открыть/Exit по B
        if key == KEY_B then
            ToggleKitMenu()
            return
        end

        if not KitMenuOpen then return end
        if not CS16DM_Config or not CS16DM_Config.kits then return end

        -- Обработка выбора цифрами
        if key >= KEY_1 and key <= KEY_9 then
            local choice = key - KEY_0

            -- 0 — Exit, 9 — Return (у нас одноступенчатое меню, Return == Exit)
            if choice == 0 or choice == 9 then
                KitMenuOpen = false
                return
            end

            local kit = CS16DM_Config.kits[choice]
            if kit then
                -- Отправляем выбранный kit.id на сервер
                net.Start("CS16DM_SelectKit")
                net.WriteString(kit.id)
                net.SendToServer()
                KitMenuOpen = false
            else
                -- если выбран номер вне диапазона — просто Exit
                KitMenuOpen = false
            end
        elseif key == KEY_0 then
            KitMenuOpen = false
        end
    end)

    -- Рисуем меню как HUD слева по центру
    hook.Add("HUDPaint", "CS16DM_KitMenuHUD", function()
        if not KitMenuOpen then return end

        if not CS16DM_Config or not CS16DM_Config.kits then
            draw.SimpleText("No load config", "Trebuchet24", 50, ScrH() / 2 - 150, Color(255, 80, 80))
            return
        end

        local x = 50
        local y = ScrH() / 2 - 150

        draw.SimpleText("=== Choose Set ===", "Trebuchet24", x, y, Color(255, 255, 0))
        y = y + 30

        for i, kit in ipairs(CS16DM_Config.kits) do
            draw.SimpleText(i .. ". " .. kit.name, "Trebuchet18", x, y, Color(255, 255, 255))
            y = y + 20
        end

        draw.SimpleText("9. Return", "Trebuchet18", x, y, Color(200, 200, 200)); y = y + 20
        draw.SimpleText("0. Exit", "Trebuchet18", x, y, Color(200, 200, 200))
    end)
end

-- Серверная часть: при получении выбора — выдаём комплект
if SERVER then
    -- util.AddNetworkString("CS16DM_SelectKit") зарегистрирован в init.lua — именно там и оставляем

    local function GiveKit(ply, kit)
        if not IsValid(ply) then return end
        if not kit then return end

        -- Стандарт: чистим и выдаём нож
        ply:StripWeapons()

        -- У многих сборок нож — tfa_cs16_knife; если у вас другой класс ножа, замени тут
        ply:Give("tfa_cs16_knife")

        -- Пистолет и основное
        if kit.pistol then
            ply:Give(kit.pistol)
        end
        if kit.primary then
            ply:Give(kit.primary)
        end

        -- Гранаты
        if istable(kit.grenades) then
            for _, g in ipairs(kit.grenades) do
                if isstring(g) then
                    ply:Give(g)
                end
            end
        end

        -- Броня (сам айтем из набора + реальное значение брони)
        if kit.armor then
            ply:Give(kit.armor)
        end
        ply:SetArmor(100)
    end

    net.Receive("CS16DM_SelectKit", function(_, ply)
        local kitId = net.ReadString()
        if not isstring(kitId) or kitId == "" then return end
        if not CS16DM_Config or not istable(CS16DM_Config.kits) then return end

        local kitMatch = nil
        for _, k in ipairs(CS16DM_Config.kits) do
            if k.id == kitId then
                kitMatch = k
                break
            end
        end

        if not kitMatch then return end

        GiveKit(ply, kitMatch)
    end)

    -- Автовыдача дефолтного кита при респавне (если включено в конфиге)
    hook.Add("PlayerSpawn", "CS16DM_AutoGiveDefaultKit", function(ply)
        if ply:Team() == TEAM_SPEC then return end
        if not CS16DM_Config or not istable(CS16DM_Config.kits) then return end
        if not CS16DM_Config.autogiveDefault then return end

        local defaultKit = CS16DM_Config.kits[1]
        if defaultKit then
            GiveKit(ply, defaultKit)
        end
    end)
end
