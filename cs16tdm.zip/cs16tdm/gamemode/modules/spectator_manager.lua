-- =========================
--  Spectator Manager
-- =========================

if SERVER then
    local specModes = { OBS_MODE_IN_EYE, OBS_MODE_CHASE, OBS_MODE_ROAMING }

    local function EnterSpectator(ply)
        if not IsValid(ply) then return end
        ply:StripWeapons()
        ply:Spectate(OBS_MODE_ROAMING)
        ply:SetNoDraw(true)
        ply:SetNotSolid(true)
        ply:DrawShadow(false)
        ply:SetMoveType(MOVETYPE_NOCLIP)
    end

    local function ExitSpectator(ply)
        if not IsValid(ply) then return end
        ply:UnSpectate()
        ply:SetNoDraw(false)
        ply:SetNotSolid(false)
        ply:DrawShadow(true)
        ply:SetMoveType(MOVETYPE_WALK)
    end

    -- Спавн: SPEC всегда наблюдатель, без оружия
    hook.Add("PlayerSpawn", "CS16DM_SpecSetup", function(ply)
        if ply:Team() == TEAM_SPEC then
            EnterSpectator(ply)
        else
            ExitSpectator(ply)
        end
    end)

    -- Смена команды: вход/выход из SPEC
    hook.Add("PlayerSetTeam", "CS16DM_SpecOnTeamChange", function(ply, oldTeam, newTeam)
        if newTeam == TEAM_SPEC then
            ply:KillSilent()
            EnterSpectator(ply)
        else
            ExitSpectator(ply)
        end
    end)

    -- Запрет SPEC подбирать оружие/предметы и получать урон
    hook.Add("PlayerCanPickupWeapon", "CS16DM_SpecNoPickup", function(ply, wep)
        if ply:Team() == TEAM_SPEC then return false end
    end)
    hook.Add("PlayerCanPickupItem", "CS16DM_SpecNoPickupItem", function(ply, item)
        if ply:Team() == TEAM_SPEC then return false end
    end)
    hook.Add("PlayerShouldTakeDamage", "CS16DM_SpecNoDamage", function(ply, attacker)
        if ply:Team() == TEAM_SPEC then return false end
    end)

    -- Помощники: список допустимых целей
local function GetAlivePlayers()
    local list = {}
    for _, p in ipairs(player.GetAll()) do
        if IsValid(p)
        and p:Alive()
        and p:Team() ~= TEAM_SPEC then
            table.insert(list, p)
        end
    end
    return list
end

local function SpectateCycle(ply, dir)
    if not IsValid(ply) or ply:Team() ~= TEAM_SPEC then return end
    local targets = GetAlivePlayers()
    if #targets == 0 then
        ply:SpectateEntity(nil)
        ply:Spectate(OBS_MODE_ROAMING)
        return
    end

    -- текущая цель
    local current = ply:GetObserverTarget()
    local idx = 1
    if IsValid(current) then
        for i, t in ipairs(targets) do
            if t == current then idx = i break end
        end
    end

    idx = idx + (dir or 1)
    if idx > #targets then idx = 1 end
    if idx < 1 then idx = #targets end

    ply:SpectateEntity(targets[idx])
end

    -- Net: смена режима камеры
    net.Receive("CS16DM_Spec_SetMode", function(_, ply)
        if ply:Team() ~= TEAM_SPEC then return end
        local mode = net.ReadInt(8)
        if mode ~= OBS_MODE_IN_EYE and mode ~= OBS_MODE_CHASE and mode ~= OBS_MODE_ROAMING then return end

        ply:Spectate(mode)
        if mode ~= OBS_MODE_ROAMING then
            -- гарантируем, что есть цель
            if not IsValid(ply:GetObserverTarget()) then
                SpectateCycle(ply, 1)
            end
        else
            ply:SpectateEntity(nil)
        end
    end)

    -- Net: следующий/предыдущий игрок
    net.Receive("CS16DM_Spec_Next", function(_, ply)
        if ply:Team() ~= TEAM_SPEC then return end
        SpectateCycle(ply, 1)
    end)
    net.Receive("CS16DM_Spec_Prev", function(_, ply)
        if ply:Team() ~= TEAM_SPEC then return end
        SpectateCycle(ply, -1)
    end)
end

if CLIENT then
    local specModes = { OBS_MODE_IN_EYE, OBS_MODE_CHASE, OBS_MODE_ROAMING }

    hook.Add("KeyPress", "CS16DM_SpecControls", function(ply, key)
        if ply ~= LocalPlayer() then return end
        if ply:Team() ~= TEAM_SPEC then return end

        -- ПРОБЕЛ: цикличная смена режима
        if key == IN_JUMP then
            local cur = ply:GetObserverMode()
            local idx = table.KeyFromValue(specModes, cur) or 3
            local nextMode = specModes[(idx % #specModes) + 1]
            net.Start("CS16DM_Spec_SetMode")
            net.WriteInt(nextMode, 8)
            net.SendToServer()
        end

        -- ЛКМ/ПКМ: переключение цели
        if key == IN_ATTACK then
            net.Start("CS16DM_Spec_Next")
            net.SendToServer()
        elseif key == IN_ATTACK2 then
            net.Start("CS16DM_Spec_Prev")
            net.SendToServer()
        end
    end)
end
