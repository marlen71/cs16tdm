-- =========================
--  Round Manager
-- =========================
if SERVER then
    util.AddNetworkString("CS16DM_RoundSound")

    -- Запуск раунда
    function CS16DM_StartRound()
        -- Сброс статистики
        for _, ply in ipairs(player.GetAll()) do
            if IsValid(ply) then
                ply:SetFrags(0)
                ply:SetDeaths(0)
                ply:SetNWInt("CS16DM_Kills", 0)
                ply:Spawn()
            end
        end

        -- Звук начала раунда
        net.Start("CS16DM_RoundSound")
        net.WriteString("cs16dm/prepare.wav")
        net.Broadcast()
    end

    -- Конец раунда (например, при смене карты)
    function CS16DM_EndRound()
        net.Start("CS16DM_RoundSound")
        net.WriteString("cs16dm/oneandonly.wav")
        net.Broadcast()
    end

    -- Голосование за рестарт матча
    local votes = {}
    hook.Add("PlayerSay", "CS16DM_VoteRestart", function(ply, text)
        if string.lower(text) == "!vrm" then
            if votes[ply] then return "" end
            votes[ply] = true

            local total = #player.GetAll()
            local count = table.Count(votes)
            PrintMessage(HUD_PRINTTALK, ply:Nick().." проголосовал за рестарт ("..count.."/"..total..")")

            if count > total/2 then
                PrintMessage(HUD_PRINTTALK, "Большинство проголосовало! Рестарт матча...")
                votes = {}
                CS16DM_StartRound()
            end
            return ""
        end
    end)

    -- Автоматический старт при загрузке карты
    hook.Add("Initialize", "CS16DM_AutoStart", function()
        timer.Simple(2, function()
            CS16DM_StartRound()
        end)
    end)
end

if CLIENT then
    net.Receive("CS16DM_RoundSound", function()
        local snd = net.ReadString()
        surface.PlaySound(snd)
    end)
end
