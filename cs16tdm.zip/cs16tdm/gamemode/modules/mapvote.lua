-- =========================
--  Map Vote
-- =========================

if SERVER then
    util.AddNetworkString("CS16DM_StartMapVote")
    util.AddNetworkString("CS16DM_CastVote")

    CS16DM_MapWhitelist = {
        "gm_extrapool",
        "de_gold_dust2"
    }

    function CS16DM_StartMapVote()
        local maps = CS16DM_MapWhitelist or {}
        net.Start("CS16DM_StartMapVote")
        net.WriteUInt(#maps, 8)
        for _, map in ipairs(maps) do
            net.WriteString(map)
        end
        net.Broadcast()

        local votes = {}

        net.Receive("CS16DM_CastVote", function(len, ply)
            local choice = net.ReadUInt(8)
            if maps[choice] then
                votes[ply] = choice
                ply:ChatPrint("Ты проголосовал за "..maps[choice])
            end
        end)

        timer.Simple(15, function()
            local results = {}
            for _, choice in pairs(votes) do
                results[choice] = (results[choice] or 0) + 1
            end

            local winner, maxVotes = nil, -1
            for id, count in pairs(results) do
                if count > maxVotes then
                    winner, maxVotes = id, count
                end
            end

            if winner then
                RunConsoleCommand("changelevel", maps[winner])
            else
                RunConsoleCommand("changelevel", game.GetMap())
            end
        end)
    end
end

if CLIENT then
    local VoteFrame

    net.Receive("CS16DM_StartMapVote", function()
        local count = net.ReadUInt(8)
        local maps = {}
        for i=1,count do
            maps[i] = net.ReadString()
        end

        -- затемнение экрана
        VoteFrame = vgui.Create("DFrame")
        VoteFrame:SetSize(ScrW(), ScrH())
        VoteFrame:Center()
        VoteFrame:SetTitle("")
        VoteFrame:ShowCloseButton(false)
        VoteFrame:SetDraggable(false)
        VoteFrame:MakePopup()
        VoteFrame:SetKeyboardInputEnabled(false)

        VoteFrame.Paint = function(self,w,h)
            surface.SetDrawColor(0,0,0,200)
            surface.DrawRect(0,0,w,h)
            draw.SimpleText("Голосование за карту", "Trebuchet24", w/2, 50, Color(255,215,0), TEXT_ALIGN_CENTER)
        end

        local y = 120
        for i,map in ipairs(maps) do
            local btn = vgui.Create("DButton", VoteFrame)
            btn:SetSize(300,40)
            btn:SetPos(ScrW()/2-150, y)
            btn:SetText(map)
            btn.DoClick = function()
                net.Start("CS16DM_CastVote")
                net.WriteUInt(i, 8)
                net.SendToServer()
                VoteFrame:Remove()
            end
            y = y + 50
        end
    end)

    -- Блокируем движение и стрельбу во время голосования
    hook.Add("StartCommand", "CS16DM_BlockInputDuringVote", function(ply, cmd)
        if IsValid(VoteFrame) then
            cmd:ClearMovement()
            cmd:RemoveKey(IN_ATTACK)
            cmd:RemoveKey(IN_ATTACK2)
            cmd:RemoveKey(IN_USE)
        end
    end)
end
