-- =========================
--  HUD Client
-- =========================

if CLIENT then
    -- Создаём шрифт для крупного текста победы
    surface.CreateFont("CS16DM_WinFont", {
        font = "Trebuchet MS",
        size = 48,
        weight = 800
    })

    -- Основной HUD: счёт и таймер
    hook.Add("HUDPaint", "CS16DM_TopCenterHUD", function()
        local w = ScrW()
        local tScore = GetGlobalInt("CS16DM_Score_T", 0)
        local ctScore = GetGlobalInt("CS16DM_Score_CT", 0)

        -- Счёт
        draw.SimpleText("CT: "..ctScore, "Trebuchet24", w*0.5 - 60, 20, Color(80,120,255), TEXT_ALIGN_RIGHT)
        draw.SimpleText("|",             "Trebuchet24", w*0.5,      20, Color(255,255,255), TEXT_ALIGN_CENTER)
        draw.SimpleText("T: "..tScore,  "Trebuchet24", w*0.5 + 60, 20, Color(255,100,100), TEXT_ALIGN_LEFT)

        -- Таймер
        local timeLeft = math.max(0, math.floor(GetGlobalFloat("CS16DM_TimeEnd", CurTime()) - CurTime()))
        local mins = math.floor(timeLeft / 60)
        local secs = timeLeft % 60
        draw.SimpleText(string.format("%02d:%02d", mins, secs), "Trebuchet24", w*0.5, 45, Color(255,255,255), TEXT_ALIGN_CENTER)
    end)

    -- Сообщение о победителе
    net.Receive("CS16DM_ShowWinMessage", function()
        local msg = net.ReadString()
        local col = net.ReadColor()

        hook.Add("HUDPaint", "CS16DM_WinMessage", function()
            draw.SimpleTextOutlined(msg, "CS16DM_WinFont", ScrW()/2, ScrH()/2, col,
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0,0,0,200))
        end)

        -- Убираем через 5 секунд
        timer.Simple(5, function()
            hook.Remove("HUDPaint", "CS16DM_WinMessage")
        end)
    end)
end
