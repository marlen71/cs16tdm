-- cl_init.lua
include("shared.lua")

-- Конфиг должен быть загружен первым
include("modules/config.lua")
include("modules/killvoice.lua")
local clientModules = {
    "modules/hud_client.lua",
    "modules/scoreboard.lua",
    "modules/mapvote.lua",
    "modules/buymenu.lua",
    "modules/team_menu.lua",
    "modules/spectator_manager.lua",
    "modules/damage_feedback.lua", -- 🔹 сюда
    "modules/killvoice.lua",
    "modules/round_manager.lua" 
}
for _, f in ipairs(clientModules) do
    include(f)
end
