-- shared.lua — общая часть
GM.Name    = "[CS-1.6]TDM"
GM.Author  = "Максим"

--DeriveGamemode("sandbox") -- если хочешь базироваться на sandbox

function GM:SpawnMenuOpen() return false end
function GM:ContextMenuOpen() return false end

-- Константы команд
TEAM_SPEC = 1
TEAM_T    = 2
TEAM_CT   = 3

-- Названия команд
team.SetUp(TEAM_SPEC, "Spectators", Color(200,200,200))
team.SetUp(TEAM_T,    "Terrorists", Color(220,180,60))
team.SetUp(TEAM_CT,   "Counter-Terrorists", Color(60,120,220))

-- Модели игроков
CS16DM_MODELS_T = {
    "models/cs/playermodels/leet.mdl",
    "models/cs/playermodels/arctic.mdl",
    "models/cs/playermodels/guerilla.mdl",
    "models/cs/playermodels/terror.mdl"
}
CS16DM_MODELS_CT = {
    "models/cs/playermodels/urban.mdl",
    "models/cs/playermodels/sas.mdl",
    "models/cs/playermodels/gsg9.mdl",
    "models/cs/playermodels/gign.mdl"
}

-- Категории оружия (пистолеты, винтовки, гранаты и т.д.)
CS16DM_CATEGORIES = {
    pistols = {
        name = "Pistols",
        list = {
            {name="Glock18 (T default)", class="tfa_cs16_glock18"},
            {name="USP (CT default)",    class="tfa_cs16_usp"},
            {name="Desert Eagle",        class="tfa_cs16_deagle"},
            {name="Dual Elites",         class="tfa_cs16_elite"},
            {name="P228",                class="tfa_cs16_p228"},
            {name="Five-Seven",          class="tfa_cs16_fiveseven"},
        }
    },
    rifles = {
        name = "Rifles",
        list = {
            {name="AK-47", class="tfa_cs16_ak47"},
            {name="M4A1",  class="tfa_cs16_m4a1"},
            {name="AUG",   class="tfa_cs16_aug"},
            {name="FAMAS", class="tfa_cs16_famas"},
            {name="Galil", class="tfa_cs16_galil"},
            {name="SG-552",class="tfa_cs16_sg552"},
            {name="AWP",   class="tfa_cs16_awp"},
            {name="Scout", class="tfa_cs16_scout"},
            {name="G3SG1", class="tfa_cs16_g3sg1"},
            {name="SG-550",class="tfa_cs16_sg550"},
        }
    },
    smg = {
        name = "SMG",
        list = {
            {name="MP5 Navy", class="tfa_cs16_mp5navy"},
            {name="MAC-10",   class="tfa_cs16_mac10"},
            {name="UMP-45",   class="tfa_cs16_ump45"},
            {name="TMP",      class="tfa_cs16_tmp"},
            {name="P90",      class="tfa_cs16_p90"},
        }
    },
    shotguns = {
        name = "Shotguns",
        list = {
            {name="M3",     class="tfa_cs16_m3"},
            {name="XM1014", class="tfa_cs16_xm1014"},
        }
    },
    mg = {
        name = "Machineguns",
        list = {
            {name="M249", class="tfa_cs16_m249"},
        }
    },
    grenades = {
        name = "Grenades",
        list = {
            {name="Flashbang",     class="weapon_cs16_flashbang"},
            {name="HE Grenade",    class="weapon_cs16_hegrenade"},
            {name="Smoke Grenade", class="weapon_cs16_smokegrenade"},
        }
    },
    armor = {
        name = "Equipment",
        list = {
            {name="Kevlar",          class="cs16_kevlar"},
            {name="Kevlar + Helmet", class="cs16_kevlarhelmet"},
            {name="Defuse Kit",      class="cs16_defuser"},
            {name="C4 Backpack",     class="cs16_backpack"}, -- для T, но не в меню
        }
    }
}

-- Глобальные значения для HUD
SetGlobalInt("CS16DM_Score_T", 0)
SetGlobalInt("CS16DM_Score_CT", 0)
SetGlobalFloat("CS16DM_TimeEnd", CurTime())

-- ConVars (только сервер)
if SERVER then
    CreateConVar("cs16tdm_score_limit", "50", FCVAR_ARCHIVE, "Kills to win")
    CreateConVar("cs16tdm_time_limit", "900", FCVAR_ARCHIVE, "Match time in seconds")
end
